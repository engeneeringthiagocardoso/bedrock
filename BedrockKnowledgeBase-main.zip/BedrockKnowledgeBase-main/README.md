
# First, run Backend

# Than, run Frontend

# Prerequisite: 

You need to have a Bedrock Knowledge Base deployed.

```
https://docs.aws.amazon.com/bedrock/latest/userguide/knowledge-base-create.html
```