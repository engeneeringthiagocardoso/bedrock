bucket_nameFrontEnd = "<S3_BUCKEY_NAME_TO_BE_CREATE>"
KNOWLEDGE_BASE_ID = "<KNOWLEDGE_BASE_ID>"
PROMPT_BASE = "Você é um assistente que auxilia professores nas aulas, execute o seguinte pedido: {texto}. Traga o resultado formatado da melhor forma"